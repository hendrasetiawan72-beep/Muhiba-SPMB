import { createClient } from '@supabase/supabase-js';
import crypto from 'crypto';

// Vercel / Cloudflare Worker: POST /api/admin/reset-password
//
// Reset password oleh panitia dengan pengaman berlapis:
//   1. Hanya admin (JWT + role dari tabel profiles).
//   2. Akun admin tidak bisa direset lewat endpoint ini.
//   3. Verifikasi identitas pemohon: nomor pendaftaran + nomor WA harus cocok
//      (tanggal lahir opsional, dicocokkan bila ada datanya).
//   4. Pembatasan frekuensi: per pendaftar dan per admin (dihitung dari activity_logs).
//   5. Password sementara acak, penanda must_change_password, sesi lama dicabut.
//   6. Setiap percobaan (berhasil / gagal) dicatat di activity_logs.
//   7. Password sementara TIDAK PERNAH dikembalikan oleh endpoint ini. Ia disimpan terenkripsi
//      (AES-256-GCM) sebagai rahasia SEKALI-TAMPIL dan diambil admin yang sama lewat
//      POST /api/admin/reset-password-reveal (TTL singkat, atomik, ciphertext dikosongkan).

const MAX_RESET_PER_TARGET_24H = 3; // maksimal reset berhasil per pendaftar per 24 jam
const MAX_ATTEMPTS_PER_ADMIN_1H = 20; // maksimal percobaan (berhasil + gagal) per admin per jam

const normAlnum = (v: unknown): string =>
  String(v ?? '')
    .replace(/[^A-Za-z0-9]/g, '')
    .toUpperCase();

const normPhone = (v: unknown): string => {
  let d = String(v ?? '').replace(/\D/g, '');
  if (!d) return '';
  if (d.startsWith('62')) d = '0' + d.slice(2);
  else if (!d.startsWith('0')) d = '0' + d;
  return d;
};

// Terima YYYY-MM-DD, DD-MM-YYYY, atau DD/MM/YYYY -> YYYY-MM-DD (null bila tidak valid)
const normDate = (v: unknown): string | null => {
  const s = String(v ?? '').trim();
  if (!s) return null;
  let m = s.match(/^(\d{4})-(\d{1,2})-(\d{1,2})/);
  if (m) return `${m[1]}-${m[2].padStart(2, '0')}-${m[3].padStart(2, '0')}`;
  m = s.match(/^(\d{1,2})[-/](\d{1,2})[-/](\d{4})$/);
  if (m) return `${m[3]}-${m[2].padStart(2, '0')}-${m[1].padStart(2, '0')}`;
  return null;
};

import { applyCors } from '../../server/corsHelper';
import { encryptSecret, isUuid } from '../../server/security';

const SECRET_TTL_SECONDS = 300; // password sementara hanya bisa diambil dalam 5 menit

export default async function handler(req: any, res: any) {
  if (!applyCors(req, res)) {
    return;
  }

  res.setHeader('Content-Type', 'application/json');
  res.setHeader('Cache-Control', 'no-store');

  if (req.method === 'OPTIONS') {
    return res.status(200).json({ success: true });
  }

  if (req.method !== 'POST') {
    return res.status(405).json({ success: false, message: 'Metode tidak diizinkan.' });
  }

  const supabaseUrl = process.env.SUPABASE_URL || process.env.VITE_SUPABASE_URL || '';
  const supabaseServiceKey = process.env.SUPABASE_SERVICE_ROLE_KEY || '';

  if (!supabaseUrl || !supabaseServiceKey) {
    return res.status(500).json({ success: false, message: 'Konfigurasi server belum lengkap.' });
  }

  const supabaseAdmin = createClient(supabaseUrl, supabaseServiceKey, {
    auth: { autoRefreshToken: false, persistSession: false },
  });

  try {
    // 1. Verifikasi token pemanggil
    const authHeader = req.headers.authorization || '';
    const token = authHeader.replace(/^Bearer\s+/i, '').trim();

    if (!token) {
      return res.status(401).json({ success: false, message: 'Autentikasi diperlukan. Token tidak ditemukan.' });
    }

    const { data: callerData, error: callerErr } = await supabaseAdmin.auth.getUser(token);
    if (callerErr || !callerData?.user) {
      return res.status(401).json({ success: false, message: 'Token sesi kedaluwarsa atau tidak valid.' });
    }
    const callerId = callerData.user.id;

    // 2. Pastikan role admin dari tabel profiles
    const { data: callerProfile, error: profileErr } = await supabaseAdmin
      .from('profiles')
      .select('role, full_name')
      .eq('id', callerId)
      .maybeSingle();

    if (profileErr || callerProfile?.role !== 'admin') {
      return res.status(403).json({ success: false, message: 'Akses ditolak: Hanya administrator yang diizinkan.' });
    }
    const callerName = callerProfile?.full_name || 'Administrator';

    let body = req.body;
    if (typeof body === 'string') {
      try {
        body = JSON.parse(body);
      } catch {
        return res.status(400).json({ success: false, message: 'Invalid JSON body.' });
      }
    }

    const targetUserId = typeof body?.user_id === 'string' ? body.user_id.trim() : '';
    const targetNik = typeof body?.nik === 'string' ? body.nik.trim() : '';

    if ((targetUserId && !isUuid(targetUserId)) || targetNik.length > 32) {
      return res.status(400).json({ success: false, message: 'Identitas pendaftar target tidak valid.' });
    }
    const verifikasi = body?.verifikasi && typeof body.verifikasi === 'object' ? body.verifikasi : {};

    if (!targetUserId && !targetNik) {
      return res.status(400).json({ success: false, message: 'user_id atau NIK siswa target wajib dicantumkan.' });
    }

    // 3. Cari data pendaftar target
    let studentQuery = supabaseAdmin
      .from('students')
      .select('id, user_id, nik, nama_lengkap, nomor_pendaftaran, no_wa, data_diri');
    studentQuery = targetUserId ? studentQuery.eq('user_id', targetUserId) : studentQuery.eq('nik', targetNik);
    const { data: student, error: studentErr } = await studentQuery.maybeSingle();

    if (studentErr || !student?.user_id) {
      return res.status(404).json({ success: false, message: 'Data pendaftar tidak ditemukan.' });
    }
    const userId: string = student.user_id;

    // 4. Akun admin (atau akun sendiri) tidak boleh direset lewat fitur ini
    const { data: targetProfile } = await supabaseAdmin
      .from('profiles')
      .select('role')
      .eq('id', userId)
      .maybeSingle();

    if (targetProfile?.role === 'admin' || userId === callerId) {
      return res.status(403).json({
        success: false,
        message: 'Akun administrator tidak dapat direset lewat fitur ini.',
      });
    }

    // 5. Pembatasan frekuensi (dihitung dari activity_logs)
    const since1h = new Date(Date.now() - 60 * 60 * 1000).toISOString();
    const since24h = new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString();

    const { count: adminAttempts, error: adminCountErr } = await supabaseAdmin
      .from('activity_logs')
      .select('id', { count: 'exact', head: true })
      .eq('actor_id', callerId)
      .in('action', ['RESET_PASSWORD', 'RESET_PASSWORD_GAGAL'])
      .gte('created_at', since1h);

    if (adminCountErr) {
      console.error('[Admin Reset Password] activity_logs tidak siap:', adminCountErr.message);
      return res.status(500).json({
        success: false,
        message: 'Log aktivitas belum siap. Jalankan SQL migrasi pemulihan password di Supabase terlebih dahulu.',
      });
    }

    const { count: targetResets, error: targetCountErr } = await supabaseAdmin
      .from('activity_logs')
      .select('id', { count: 'exact', head: true })
      .eq('action', 'RESET_PASSWORD')
      .eq('target_student_id', student.id)
      .gte('created_at', since24h);

    if (targetCountErr) {
      console.error('[Admin Reset Password] Gagal membaca log:', targetCountErr.message);
      return res.status(500).json({ success: false, message: 'Gagal memeriksa batas reset. Coba lagi.' });
    }

    if ((adminAttempts ?? 0) >= MAX_ATTEMPTS_PER_ADMIN_1H) {
      return res.status(429).json({
        success: false,
        message: 'Terlalu banyak percobaan reset dari akun Anda. Coba lagi dalam 1 jam.',
      });
    }
    if ((targetResets ?? 0) >= MAX_RESET_PER_TARGET_24H) {
      return res.status(429).json({
        success: false,
        message: `Pendaftar ini sudah direset ${MAX_RESET_PER_TARGET_24H} kali dalam 24 jam terakhir. Coba lagi besok atau hubungi pengelola sistem.`,
      });
    }

    // 6. Verifikasi identitas pemohon (jawaban diketik admin, dicocokkan dengan data tercatat)
    const nomorInput = normAlnum(verifikasi.nomor_pendaftaran);
    const okNomor = nomorInput !== '' && nomorInput === normAlnum(student.nomor_pendaftaran);

    const waInput = normPhone(verifikasi.no_wa);
    const okWa = waInput !== '' && waInput === normPhone(student.no_wa);
    const dobInput = String(verifikasi.tanggal_lahir ?? '').trim();
    if (!dobInput) {
      return res.status(400).json({
        success: false,
        message: 'Tanggal lahir pemohon wajib diisi untuk verifikasi keamanan.',
      });
    }

    let dobOnFile = normDate((student.data_diri as any)?.tanggal_lahir);
    // Jika belum tercatat di data_diri, turunkan dari 6 digit tanggal lahir di NIK
    if (!dobOnFile && student.nik && student.nik.length === 16) {
      let d = parseInt(student.nik.slice(6, 8), 10);
      if (d > 40) d -= 40; // perempuan
      const m = student.nik.slice(8, 10);
      const y = student.nik.slice(10, 12);
      const fullYear = parseInt(y, 10) > 40 ? `19${y}` : `20${y}`;
      dobOnFile = `${fullYear}-${m}-${String(d).padStart(2, '0')}`;
    }

    const okDob = dobOnFile ? normDate(dobInput) === normDate(dobOnFile) : false;
    const dobStatus = okDob ? 'cocok' : 'tidak cocok';

    const logBase = {
      actor_id: callerId,
      actor_name: callerName,
      target_student_id: student.id,
      target_nik: student.nik,
      target_nama: student.nama_lengkap,
      target_nomor: student.nomor_pendaftaran,
    };

    if (!(okNomor && okWa && okDob)) {
      // Catat kegagalan tanpa merinci kolom mana yang salah
      const { error: failLogErr } = await supabaseAdmin.from('activity_logs').insert({
        ...logBase,
        action: 'RESET_PASSWORD_GAGAL',
        detail: { alasan: 'verifikasi_tidak_cocok' },
      });
      if (failLogErr) console.error('[Admin Reset Password] Gagal mencatat log gagal:', failLogErr.message);

      return res.status(403).json({
        success: false,
        message: 'Data verifikasi tidak cocok. Pastikan jawaban pemohon sesuai data pendaftaran.',
      });
    }

    // 7. Password sementara acak (Mhb@ + 12 karakter heksadesimal)
    const tempPassword = `Mhb@${crypto.randomBytes(6).toString('hex')}`;

    // Simpan password sementara sebagai rahasia sekali-tampil (terenkripsi) SEBELUM mengubah
    // password Auth. Bila penyimpanan gagal, tidak ada perubahan apa pun pada akun siswa.
    let secretId = '';
    try {
      const ciphertext = await encryptSecret(tempPassword, `${callerId}:${userId}`);
      const expiresAt = new Date(Date.now() + SECRET_TTL_SECONDS * 1000).toISOString();

      // bersihkan rahasia kedaluwarsa (best effort)
      await supabaseAdmin
        .from('password_reset_secrets')
        .delete()
        .lt('expires_at', new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString());

      const { data: secretRow, error: secretErr } = await supabaseAdmin
        .from('password_reset_secrets')
        .insert({ actor_id: callerId, target_user_id: userId, ciphertext, expires_at: expiresAt })
        .select('id')
        .single();
      if (secretErr || !secretRow?.id) throw new Error(secretErr?.message || 'SECRET_INSERT_FAILED');
      secretId = secretRow.id;
    } catch (secretEx: any) {
      console.error('[Admin Reset Password] Penyimpanan rahasia sekali-tampil gagal:', secretEx?.message);
      return res.status(503).json({
        success: false,
        message: 'Layanan reset password belum siap. Hubungi pengelola sistem.',
      });
    }
    const discardSecret = async () => {
      try {
        await supabaseAdmin.from('password_reset_secrets').delete().eq('id', secretId);
      } catch {
        /* best effort */
      }
    };

    // Update kata sandi Auth terlebih dahulu (jika gagal, flag must_change_password belum berubah)
    const { error: updateErr } = await supabaseAdmin.auth.admin.updateUserById(userId, {
      password: tempPassword,
    });

    if (updateErr) {
      console.error('[Admin Reset Password] Error updateUserById:', updateErr.message);
      await discardSecret();
      return res.status(500).json({
        success: false,
        message: 'Gagal memperbarui kata sandi akun. Silakan coba lagi.',
      });
    }

    // 8. Cabut semua sesi lama (token lama tidak bisa diperpanjang)
    let sessionsRevoked = false;
    try {
      const { data: revData, error: revokeErr } = await supabaseAdmin.rpc('revoke_user_sessions', { p_user_id: userId });
      if (revokeErr || revData === false) {
        console.error('[Admin Reset Password] Gagal mencabut sesi:', revokeErr?.message || 'RPC returned false');
      } else {
        sessionsRevoked = true;
      }
    } catch (e: any) {
      console.error('[Admin Reset Password] Gagal mencabut sesi:', e?.message);
    }

    if (!sessionsRevoked) {
      try {
        await supabaseAdmin.from('activity_logs').insert({
          ...logBase,
          action: 'RESET_PASSWORD_FAILED',
          detail: {
            alasan: 'SESSION_REVOCATION_FAILED',
            verifikasi: { nomor_pendaftaran: 'cocok', no_wa: 'cocok', tanggal_lahir: dobStatus },
          },
        });
      } catch (logErr) {
        console.error('[Admin Reset Password] Gagal mencatat log kegagalan:', logErr);
      }
      await discardSecret();
      return res.status(503).json({
        success: false,
        code: 'SESSION_REVOCATION_FAILED',
        message: 'Password belum dapat direset karena sesi lama gagal dicabut.',
      });
    }

    // 9. Tandai wajib ganti kata sandi setelah update auth dan pencabutan sesi berhasil
    const { error: flagErr } = await supabaseAdmin
      .from('profiles')
      .update({ must_change_password: true })
      .eq('id', userId);

    if (flagErr) {
      console.error('[Admin Reset Password] Gagal menandai must_change_password:', flagErr.message);
      try {
        await supabaseAdmin.from('activity_logs').insert({
          ...logBase,
          action: 'RESET_PASSWORD_FAILED',
          detail: {
            alasan: 'PASSWORD_FLAG_UPDATE_FAILED',
            error: flagErr.message,
          },
        });
      } catch (logErr) {
        console.error('[Admin Reset Password] Gagal mencatat log flag error:', logErr);
      }
      await discardSecret();
      return res.status(500).json({
        success: false,
        code: 'PASSWORD_FLAG_UPDATE_FAILED',
        message: 'Password berubah, tetapi status wajib ganti password gagal disimpan.',
      });
    }

    // 10. Catat audit log keberhasilan (password TIDAK ikut dicatat)
    const { error: logErr } = await supabaseAdmin.from('activity_logs').insert({
      ...logBase,
      action: 'RESET_PASSWORD',
      detail: {
        metode: 'reset_panitia',
        password_delivery: 'one_time_secret',
        verifikasi: { nomor_pendaftaran: 'cocok', no_wa: 'cocok', tanggal_lahir: dobStatus },
        sesi_dicabut: true,
        must_change_password_set: true,
      },
    });
    if (logErr) console.error('[Admin Reset Password] Gagal mencatat log:', logErr.message);

    return res.status(200).json({
      success: true,
      // Password sementara TIDAK disertakan. Ambil sekali lewat /api/admin/reset-password-reveal.
      secret_id: secretId,
      secret_expires_in: SECRET_TTL_SECONDS,
      nama_lengkap: student.nama_lengkap,
      nomor_pendaftaran: student.nomor_pendaftaran,
      no_wa: student.no_wa,
      sessionsRevoked: true,
      logged: !logErr,
      message: 'Kata sandi berhasil direset oleh administrator.',
    });
  } catch (err: any) {
    console.error('[Admin Reset Password] Unexpected error:', err?.message);
    return res.status(500).json({
      success: false,
      message: 'Terjadi kesalahan server saat mereset kata sandi.',
    });
  }
}
